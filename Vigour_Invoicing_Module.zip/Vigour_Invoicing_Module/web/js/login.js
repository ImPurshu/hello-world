/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
        $(document).ready(function(){
            $("#login").click(function(){
                
                var email=$("#emailtxt1").val();
                var password=$("#passtxt1").val();
                if( email =='vigouradmin' & password =='wasabicorp')
                {
                    window.open("welcome.jsp","_self");
                }
                else
                {
                    $("#valid1").html("Incorrect email OR password. Please try again");
                }
            });
        });

